/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/modules/exporting
 * @requires highcharts
 *
 * Exporting module
 *
 * (c) 2010-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/full-screen.src.js';
import '../../modules/exporting.src.js';
